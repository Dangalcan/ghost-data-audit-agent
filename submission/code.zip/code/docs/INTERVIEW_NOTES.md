# AI judge interview - notes

## 2-minute pitch

Northstar's workflow said "Complete" while data lived on. My agent audits that claim
from evidence. It resolves every identifier a person ever had, turns 94 heterogeneous
evidence files into one stream of timestamped observations, decides what each
resource looked like at `audit_at`, applies the retention policy record by record, and
emits an ordered, verifiable plan. Claude does the two things code cannot: it reads
multilingual request text and transcribes console screenshots. Every decision is made
by deterministic, unit-tested code, so each step can be explained with the evidence
that proves it. On the 32 public samples: 32/32 statuses, step F1 0.97, every field of
every matched step correct. Full run: 518 rows, contract validator clean. The whole
build, including the tool-using reviewer on 93 uncertain cases, cost about 2 USD in model
calls; the final run replays everything from cache.

## Architecture in 30 seconds

identity → observations → linkage → state at audit_at → policy → ordered steps.
See `ARCHITECTURE.md`.

## Likely questions

**Is this a real agent or a pipeline with LLM calls?**
Both, by design. The backbone is deterministic because the contract is exact and the
evidence is structured. On top of it runs a genuine agent loop: a Sonnet reviewer picks
its own tools (search evidence by identifier, read the raw line, look up activity,
resolve identity), iterates up to eight times, and files a strict structured review. I
gave it veto and proposal powers but made code the gatekeeper: every claim must cite a
source that code re-reads and confirms (resource named, quote verbatim, file predates
audit_at, compliance marker present). Hallucinated citations are logged as rejected and
never touch the output. I measured it: see the review section of the evaluation report.

**Why not just ask the model per case?**
518 cases × ~100 KB of evidence is expensive, slow and non-reproducible; the contract
is exact (ids, states, order, citations). Rules are testable; the model's job is
perception, not judgment.

**How do you resolve historical identities?**
`user_audit_log.csv` gives old emails / hashes / phones; I index all of them, compute
sha256 of every email (the dataset's `email_hash` convention) and match with word
boundaries and lower-casing, so `user_43` ≠ `user_4301` and `g.silva76.jr@` ≠ `g.silva76@`.

**How do you know a deleted account belongs to the subject if nothing names it?**
Readback logs join the lookup (`lookup_key=email`) to the result (`resource_id`) through
`trace_id`. When even that is missing, the deletion worker's `DELETE_RECORD` event next
to `reported_at`, whose result matches the workflow's reported status, is assigned
one-to-one; it is marked low-confidence and used only for the verification step.

**What about the screenshots?**
Claude Sonnet 5.5 transcribes them into a fixed JSON schema (resource id, record type,
identifiers, status, aliases). The data catalog rows in `system_activity.csv` tie the
intended record to a person; a record that only exists in one screenshot and nowhere
else is treated as console noise. Extractions are cached and reviewed.

**How do you handle time?**
Two checks: the record's own timestamp and the file's `captured_at` must both precede
`audit_at` (bundles embed older snapshots in newer files). Later evidence may only
tell me who owns a resource, never its state. Reported statuses and activity results
are claims.

**Replication drift?**
Each replica row is its own observation; at the same instant PRESENT beats ABSENT, so
a profile alive in the failover replica is still a remaining record.

**Policy edge cases?**
Tombstones keep `user_id` but must lose name/email/phone/hash (REDACT). Hash-only
analytics contact entries are secondary identifiers (DELETE), not profiles (ANONYMIZE).
Support attachments and legacy contact entries are deleted; conversations with shared
context are redacted. Security audit records within retention and legal holds are
retained and verified PRESENT. Backups are never deleted; restore access is blocked.

**Ordering?**
Phase, then the operation table order, then `system_id`, then `resource_id`;
remediation therefore disables flows and blocks restores before deleting records.

**Safety / prompt injection?**
Untrusted text is wrapped as data, the system prompts forbid following it, every answer
is validated against a JSON schema and closed enums, the intent and vision calls have no
tools, the reviewer's tools are read-only, and a deterministic guard flags
disagreements. The model can at most flip one label or file a citation that code
rejects; it cannot touch evidence, state or output. The parsers treat evidence as
untrusted as well: a security review before submission found that SQL snapshots ran
with full SQLite privileges (a crafted file could ATTACH or VACUUM INTO a path on the
auditor's machine); they now run under an authorizer that denies file access, and the
reviewer's tool pointers never select a file path (manifest lookup only).

**How is the code kept maintainable?**
ruff with pylint complexity limits (14 branches / 60 statements / 8 returns per
function) and full type hints; dataclasses for every record that crosses a module;
16 unit tests, 6 custom cases, the sample regression and the contract validator;
JSON schemas at every model boundary; typed retries with backoff; structured
`key=value` logging. `code/README.md` is the module map.

**Evaluation?**
Harness with case / row / step / field / sequence metrics against the public sample,
six custom cases on the decision core (historical hash, drift, non-deletion wording,
tombstone, late evidence, complete proof), unit tests for every log dialect, and a
contract validator run on `output.csv`. Failures found and fixed are in
`evaluation_report.md`.

**Cost and tokens?**
Unique request texts → Haiku 5.5 (low effort), 11 screenshots → Sonnet 5.5, 93
uncertain cases → the Sonnet 5.5 reviewer with tools (the bulk of the ≈ 2 USD). All
cached, so the final run spends nothing. See `usage_report.md`.

**What did the reviewer actually change?**
Mostly nothing, and that is the point: on the public samples it agreed with every draft;
on the hidden set it is a safety net for the low-confidence links. The value is observable
disagreement: every rejected claim is logged with the reason, which told me where my
parsers and the model see the data differently.

**What would you do with another day?**
Resolve the remaining anonymised-analytics ambiguities with a second extraction pass
over readback logs, add an LLM "second opinion" on low-confidence links, and
calibrate on more labelled cases.

## Trade-offs I made deliberately

- Precision over recall on linkage: a wrong finding changes the verdict; a missed
  retained-record verification costs one step.
- Late evidence for ownership only - documented flag, defensible, measurable.
- No model-generated steps: every emitted id comes from the data.
